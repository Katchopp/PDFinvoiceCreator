// Folder Structure:
// /public/logo.png (your logo)
// /pages/api/generate.js (PDF generation API)
// /pages/index.js (Frontend)
// /package.json

// package.json dependencies example:
// "dependencies": {
//   "next": "latest",
//   "react": "latest",
//   "react-dom": "latest",
//   "puppeteer-core": "^21.3.8",
//   "chrome-aws-lambda": "^10.1.0",
//   "tailwindcss": "latest"
// }

// /pages/index.js
import { useState } from 'react';

const HomePage = () => {
  const [form, setForm] = useState({
    customer: '',
    rooms: [],
    services: {},
    price: '',
    description: ''
  });

  const roomOptions = ['Kitchen', 'Bathroom', 'Laundry', 'Basement'];
  const serviceOptions = {
    Kitchen: ['Backsplash Installation'],
    Bathroom: ['Wall Durock Installation', 'Floor Durock Installation', 'Pour and Level Floor', 'Pour and Pitch Shower Pan', 'Wall Tile Installation', 'Floor Tile Installation', 'Niche Installation', 'Stone Pieces Installation', 'Waterproof', 'Rubber Pan Installation'],
    Laundry: ['Durock Installation', 'Floor Installation'],
    Basement: ['Preparation', 'Installation']
  };

  const handleGenerate = async () => {
    const res = await fetch('/api/generate', {
      method: 'POST',
      body: JSON.stringify(form),
      headers: { 'Content-Type': 'application/json' }
    });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${form.customer}-workorder.pdf`;
    a.click();
  };

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Work Order Generator</h1>

      <input type="text" placeholder="Customer / Project" className="border p-2 w-full mb-3" value={form.customer} onChange={e => setForm({ ...form, customer: e.target.value })} />

      <label className="block mb-2">Select Rooms:</label>
      {roomOptions.map(room => (
        <div key={room}>
          <label>
            <input type="checkbox" checked={form.rooms.includes(room)} onChange={e => {
              const rooms = e.target.checked ? [...form.rooms, room] : form.rooms.filter(r => r !== room);
              setForm({ ...form, rooms });
            }} /> {room}
          </label>
          {form.rooms.includes(room) && (
            <div className="ml-4">
              {serviceOptions[room].map(service => (
                <div key={service}>
                  <label>
                    <input type="checkbox" checked={form.services[room]?.includes(service)} onChange={e => {
                      const roomServices = form.services[room] || [];
                      const newServices = e.target.checked ? [...roomServices, service] : roomServices.filter(s => s !== service);
                      setForm({
                        ...form,
                        services: { ...form.services, [room]: newServices }
                      });
                    }} /> {service}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      <input type="number" placeholder="Total Price" className="border p-2 w-full my-3" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
      <textarea placeholder="Description" className="border p-2 w-full mb-4" rows="4" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />

      <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={handleGenerate}>Generate PDF</button>
    </div>
  );
};

export default HomePage;

// /pages/api/generate.js
import chromium from 'chrome-aws-lambda';
import puppeteer from 'puppeteer-core';

const handler = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');

  const data = req.body;
  const browser = await puppeteer.launch({
    args: chromium.args,
    defaultViewport: chromium.defaultViewport,
    executablePath: await chromium.executablePath,
    headless: chromium.headless,
  });
  const page = await browser.newPage();

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body { font-family: sans-serif; padding: 20px; }
    .header { text-align: center; }
    .title { font-weight: bold; font-size: 20px; margin-top: 10px; }
    .section-title { font-weight: bold; margin-top: 10px; }
    .red { color: red; }
  </style></head><body>
    <div class="header">
      <img src="${process.env.NEXT_PUBLIC_BASE_URL || ''}/logo.png" style="max-width:200px;" />
      <div>Gold Tile Inc. | (857) 417-1357 | gold.tile@outlook.com</div>
      <div>12 Kendall Ave #9, Framingham, MA 01702</div>
      <div class="title">Work Order / Pricing Agreement</div>
      <div>Customer / Project: ${data.customer}</div>
    </div>

    ${data.rooms.map(room => `
      <div class="section-title">${room}:</div>
      <ul>${(data.services[room] || []).map(s => `<li>${s}</li>`).join('')}</ul>
    `).join('')}

    <div class="section-title">Total: $${data.price}</div>
    <p>${data.description}</p>

    <div class="section-title">Certificate of Agreement</div>
    <p>I hereby certify I will supply all the material for this project. I hereby acknowledge this satisfactory completion of the described work and agree with the total price. I am aware that any change in the work order might affect the total price.</p>

    <div class="red">
      <ul>
        <li>50% deposit upon order placement to begin the project.</li>
        <li>25% payment upon completion of preparation work.</li>
        <li>Remaining 25% balance upon final project completion.</li>
      </ul>
    </div>
  </body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle0' });
  const pdf = await page.pdf({ format: 'A4' });
  await browser.close();

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename=workorder.pdf');
  res.send(pdf);
};

export default handler;

// Deployment:
// - Place logo.png in /public
// - Deploy on Vercel or Render
// - Set NEXT_PUBLIC_BASE_URL environment variable if needed (e.g., https://yourapp.vercel.app)
// - No database, runs entirely on frontend + serverless API
